<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => NULL, NULL, 'feng', 'lian', 'xun', 'xu', 'mi', 'hui', 'mu', 'yong', 'zhan', 'yi', 'nou', 'tang', 'xi', 'yun',
  0x10 => 'shu', 'fu', 'yi', 'da', NULL, 'lian', 'cao', 'can', 'ju', 'lu', 'su', 'nen', 'ao', 'an', 'qian', NULL,
  0x20 => 'cui', 'cong', NULL, 'ran', 'nian', 'mai', 'xin', 'yue', 'nai', 'ao', 'shen', 'ma', NULL, NULL, 'lan', 'xi',
  0x30 => 'yue', 'zhi', 'weng', 'huai', 'meng', 'niao', 'wan', 'mi', 'nie', 'qu', 'zan', 'lian', 'zhi', 'zi', 'hai', 'xu',
  0x40 => 'hao', 'xuan', 'zhi', 'mian', 'chun', 'gou', NULL, 'chun', 'luan', 'zhu', 'shou', 'liao', 'jiu', 'xie', 'ding', 'jie',
  0x50 => 'rong', 'mang', NULL, 'ke', 'yao', 'ning', 'yi', 'lang', 'yong', 'yin', 'yan', 'su', NULL, 'lin', 'ya', 'mao',
  0x60 => 'ming', 'zui', 'yu', 'yi', 'gou', 'mi', 'jun', 'wen', NULL, 'kang', 'dian', 'long', NULL, 'xing', 'cui', 'qiao',
  0x70 => 'mian', 'meng', 'qin', NULL, 'wan', 'de', 'ai', NULL, 'bian', 'nou', 'lian', 'jin', 'yu', 'chui', 'zuo', 'bo',
  0x80 => 'hui', 'yao', 'tui', 'ji', 'an', 'luo', 'ji', 'wei', 'bo', 'za', 'xu', 'nian', 'yun', NULL, 'ba', 'zhe',
  0x90 => 'ju', 'wei', 'xie', 'qi', 'yi', 'xie', 'ci', 'qiu', 'du', 'niao', 'qi', 'ji', 'tui', NULL, 'song', 'dian',
  0xA0 => 'lao', 'zhan', NULL, NULL, 'yin', 'cen', 'ji', 'hui', 'zi', 'lan', 'nao', 'ju', 'qin', 'dai', NULL, 'jie',
  0xB0 => 'xu', 'cong', 'yong', 'dou', 'chi', NULL, 'min', 'huang', 'sui', 'ke', 'zu', 'hao', 'cheng', 'xue', 'ni', 'chi',
  0xC0 => 'lian', 'an', 'mu', 'si', 'xiang', 'yang', 'hua', 'cuo', 'qiu', 'lao', 'fu', 'dui', 'mang', 'lang', 'tuo', 'han',
  0xD0 => 'mang', 'bo', 'qun', 'qi', 'han', NULL, 'long', NULL, 'tiao', 'ze', 'qi', 'zan', 'mi', 'pei', 'zhan', 'xiang',
  0xE0 => 'gang', NULL, 'qi', NULL, 'lu', NULL, 'yun', 'e', 'duan', 'min', 'wei', 'quan', 'sou', 'min', 'tu', NULL,
  0xF0 => 'ming', 'yao', 'jue', 'li', 'kuai', 'gang', 'yuan', 'da', NULL, 'lao', 'lou', 'qian', 'ao', 'biao', 'yong', 'mang',
];
